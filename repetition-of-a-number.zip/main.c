#include<stdio.h>
int main()
{
   long long int a[100],num;
   long long int count=0,flag=0,b,i,key,no;
    printf("Enter the number:");
    scanf("%lld",&num);
    printf("Enter the key digit:");
    scanf("%lld",&key);
    b=num;
    while(b!=0)
    {
        b=b/10;
        count=count+1;
        }
    no=num;
    for(i=0;i<count;i++)
    {
        a[i]=no%10;
        no=no/10;
    }
   
    for(i=0;i<count;i++)
    {
        if(key==a[i])
        flag++;
    }
    if(flag==0)
    printf("%lld appears %lld times in %lld",key,flag,num);
    else
    printf("%lld appears %lld times in %lld",key,flag,num);
    return 0;
}