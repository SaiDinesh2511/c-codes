#include<stdio.h>
int main()
{
    int input,units,price;
    char E,I;
    printf("Enter 'E' for Electric Kettle and 'I' for Induction Stove(No other character will be accepted.");
    scanf("%c",&input);
    printf("\nEnter the number of units ordered:");
    scanf("%d",&units);
    if(input==E)
    {
        if(units>=1&&units<=10)
        {
        price=950;
         printf("\nTotal amount to be paid is %d",(units*price));
    }
            if(units>=11&&units<=20)
            {
        price=900;
         printf("\nTotal amount to be paid is %d",(units*price));
}
if(units>=21)
        {
        price=850;
    printf("\nTotal amount to be paid is %d",(units*price));
    }
    }
    else if(input==I)
    {
        if(units>=1&&units<=15)
       { 
           price=1100;
         printf("\nTotal amount to be paid is %d",(units*price));
       }
        if(units>=16&&units<=25)
        {
        price=1000;
         printf("\nTotal amount to be paid is %d",(units*price));
        }
        if(units>=26)
        {
        price=975;
        printf("\nTotal amount to be paid is %d",(units*price));
    }
    }
    return 0;
}
