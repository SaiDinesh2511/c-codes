#include<stdio.h>
int main()
{
    int celsius;
    float Farenheit;
    scanf("%d",&celsius);
   Farenheit=(9*celsius/5)+(32);
    printf("%f",Farenheit);
    return 0;
}