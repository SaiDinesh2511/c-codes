#include<stdio.h>
int main()
{
    struct student
    {
        int rollno;
        char name[50];
        int age;
        int marks;
    };
    struct student stud1;
    printf("Enter the rollno:");
    scanf("%d",&stud1.rollno);
    printf("\nEnter the name:");
    scanf("%s",stud1.name);
    printf("\nEnter age:");
    scanf("%d",&stud1.age);
    printf("\nEnter marks:");
    scanf("%d",&stud1.marks);
    printf("\nRollno=%d",stud1.rollno);
    printf("\nName=%s",stud1.name);
    printf("\nAge=%d",stud1.age);
    printf("\nMarks=%d",stud1.marks);
    return 0;
}