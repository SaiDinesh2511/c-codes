#include<stdio.h>
int main()
{
    int n,i,c;
    scanf("%d",&n);
    if(n>0)

        i=n;
        while(n*i>0)
        {
            c=n*i;
            printf("Fraction:((%d*%d)/%d)",(c/i));
            i++
        }
    }
    return 0;
}