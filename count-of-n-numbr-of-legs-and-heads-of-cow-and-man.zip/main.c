#include<stdio.h>
int main()
{
    int m,n,a,b,c,d,x,y;
    printf("Enter total no of heads of x an y:");
    scanf("%d",&m);
    printf("Enter total no of legs of x and y:");
    scanf("%d",&n);
    printf("Enter no of heads and legs of x:");
    scanf("%d%d",&a,&c);;
    printf("Enter no of heads and legs of y:");
    scanf("%d%d",&b,&d);
    x=(d*m-b*n)/(a*d-b*c);
    y=(a*n-c*m)/(a*d-b*c);
    if(x+y!=m)
    printf("Invalid input");
    else
    {
    printf("no of cow:%d",x);
    printf("\nno of men:%d",y);
    }
    return 0;
    }
