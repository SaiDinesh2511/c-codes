#include<stdio.h>
int main()
{
    int first=0,second=1,next,i,n;
    printf("no of elemts\n");
    scanf("%d",&n);
    printf("enter first element");
    scanf("%d",&first);
    printf("ENter second element");
    scanf("%d",&second);
    printf("fibonacci seeries is:\n");
    printf("%d",first);
    printf("%d",second);
    for(i=1;i<=n-2;i++)
    {
        next=first+second;
        first=second;
        second=next;
    printf("%d",next);
    }
return 0;
}