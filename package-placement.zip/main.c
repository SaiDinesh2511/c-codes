#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the no of students placed in cse:");
    scanf("%d",&a);
    printf("Enter the no of students placed in ece:");
    scanf("%d",&b);
    printf("Enter the no of students placed in mech:");
    scanf("%d",&c);
    if(a<0||b<0||c<0)
    printf("input is invalid");
    else if(a==b&&a==c)
    printf("None of the department has got the highest placement");
    else if(a>b&&a>c)
    printf("Highest placements\n cse");
    else if(b>a&&b>c)
    printf("Highest placement\nece");
    else if(c>a&&c>b)
    printf("Highest placement\nmech");
    return 0;
}
    
    