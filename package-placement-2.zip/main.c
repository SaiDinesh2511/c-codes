#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter the three values:");
    scanf("%d%d%d",&a,&b,&c);
     if  (a<0||b<0||c<0)
    printf("invalid");
    else if(a==b&&a==c)
    printf("none of them got");
       else if(a>b&&a>c)
    {
      if(a==b)
      printf("cse+ece");
      else
    printf("Highest placements\n cse");
    }
    else if(b>a&&b>c)
    {
        if(b==c)
        printf("ece+mech");
        else
     printf("Highest placement\nece");
    }
    else if(c>a&&c>b)
    {
    if(a==c)
    printf("mech+cse");
    else
    printf("Highest placement\nmech");
    }
     return 0;
}
