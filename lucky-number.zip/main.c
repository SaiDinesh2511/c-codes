#include<stdio.h>
int main()
{
    int count=0,a,sum=0,num,rem;
    printf("Enter the car no:");
    scanf("%d",&num);
    a=num;
    while(a!=0)
    {
        rem=a%10;
        count=count+1;
        sum=sum+rem;
        a=a/10;
    }
    if(count==4)
    {
        if((sum%3==0)||(sum%5==0)||(sum%7==0))
        printf("lucky number");
        else
        printf("Sorry its not my lucky number");
    }
    else if((count!=4)||(num==0)||(num<0))
    printf("%d is not a valid number",num);
    return 0;
}