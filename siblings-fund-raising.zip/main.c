#include<stdio.h>
int main()
{
 int a,b,c,d;
 char e[10]={S,a,r,a}
 char f[10]={H,a,r,r,y}
 char g[10]=[L,e,o}
 char h[10]={J,a,m,e,s}
 printf("Enter the number of boxes sold by Sara:");
 scanf("%d",a);
 printf("Enter the number of boxes sold by Harry:");
 scanf("%d",b);
 printf("Enter the number of boxes sold by Leo:");
 scanf("%d",c);
 printf("Enter the number of boxes sold by James:");
  scanf("%d",d);
  if(a==b&&a==c&&a==d)
  printf("All receive same gifts");
  else if(a>b&&a>c&&a>d)
  printf("%s receive the gifts",e);
  else if(b>a&&b>c&&b>d)
  printf("%s receive the gifts",f);
  else if(c>a&&c>b&&c>d)
  printf("%s receive the gifts",g);
  else if(d>a&&d>b&&d>c)
  printf("%s receive the gifts",h);
  return 0;
}