#include<stdio.h>
int main()
{
    printf("Have a wonderful day");
    return 0;
}