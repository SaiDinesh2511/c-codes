#include<stdio.h>
int main()
{
    int year,rem,count=0,yearr;
    scanf("%d",&year);
    yearr=year;
    while(yearr!=0)
    {
        rem=yearr%10;
        count++;
        yearr=yearr/10;
    }
    
    if(year<=0||count!=4)
    printf("invalid input");
    else if((year%4==0)&&((year%400==0)||(year%100!=0)))
    printf("%d is a leap year",year);
    else
    printf("%d is not a leap year",year);
    return 0;
}