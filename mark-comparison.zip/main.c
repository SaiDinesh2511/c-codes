#include<stdio.h>
int main()
{
    int a[20],b[20],i,j,m,n,flag=0;
    scanf("%d",&m);
    for(i=0;i<m;i++)
    scanf("%d",&a[i]);
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&b[i]);
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
       if(m!=n)
       {
       printf("INvalid array size");
       break;
        }
        }
    }
     for(i=0;i<m;i++)
    {
        if(a[i]<0||b[i]<0)
            {
            printf("no negative elements");
            flag++;
            }
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i]==b[j])
            {
            flag++;
            printf("(%d,%d)",i+1,j+1);
            }
        }
    }
    if(flag==0)
    printf("No matching scores");
    return 0;
}
    

