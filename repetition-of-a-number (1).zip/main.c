#include<stdio.h>
int main()
{
    int flag=0,rem,no,num,key;
    printf("Enter the number");
    scanf("%d",&no);
    printf("enter the key digit");
    scanf("%d",&key);
    num=no;
    while(num!=0)
    {
        rem=num%10;
        if(key==rem)
        {
            flag++;
        }
        num=num/10;
    }
    if(flag==0)
    printf("%d appears %d times in %d",key,flag,no);
    else
     printf("%d appears %d times in %d",key,flag,no);
     return 0;
}