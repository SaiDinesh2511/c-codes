#include<stdio.h>
int main()
{
    int amount;
    char code[20],CAD,HKD,SGD,USD;
    printf("Enter the currency code:");
    scanf("s",code);
    printf("Enter the amount:");
    scanf("%d",&amount);
    if(code!=CAD||HKD||SGD||USD)
    printf("\nCurrency code not found");
    else if(code==CAD)
    printf("\ncanada dollar %d equals to %.2lf Indain Rupee",amount,(amount*52.08));
    else if(code==HKD)
    printf("\nHONG KONG dollar %d equals to %.2lf Indain Rupee",amount,(amount*8.86));
    else if(code==SGD)
    printf("\nSingapore dollar %d equals to %.2lf Indain Rupee",amount,(amount*51.29));
    else if(code==USD)
    printf("\nSingapore dollar %d equals to %.2lf Indain Rupee",amount,(amount*69.55));
    return 0;
}