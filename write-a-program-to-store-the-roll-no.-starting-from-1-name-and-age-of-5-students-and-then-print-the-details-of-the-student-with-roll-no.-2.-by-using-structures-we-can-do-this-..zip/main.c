#include<stdio.h>
int main()
{
    struct student
    {
        int rollno;
        char name[50];
        int age;
    };
    struct student stud[50];
    int n,i;
    printf("enter no of students");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("\nEnter the roll.no");
        scanf("%d",&stud[i].rollno);
        printf("\nEnter name:");
        scanf("%s",stud[i].name);
        printf("\nEnter age:");
        scanf("%d",&stud[i].age);
    }
    for(i=0;i<n;i++)
    {
        printf("\nrollno=%d",stud[i].rollno);
        printf("\nname=%s",stud[i].name);
        printf("\nage=%d",stud[i].age);
    }
return 0;
    }