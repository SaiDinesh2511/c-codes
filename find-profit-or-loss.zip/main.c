#include<stdio.h>
int main()
{
    int profitpercentage,lostamount,profit,investment=100000,loss,losspercentage,profitamount;
    printf("Enter the profitpercentage:");
    scanf("%d",&profitpercentage);
    printf("Enter the amount lost in Rs.");
    scanf("%d",&lostamount);
    profit=(profit/100)*(investment);
    loss=(lostamount-profit);
    if(loss==profit)
    printf("After two years he gets no loss or no gain.");
    if(profit>loss)
    {
        profitpercentage=(profitamount/investment)*100;
    printf("After two years he gets a loss of %d.",profitpercentage);
         }
         if(loss>profit)
         {
             losspercentage=(lostamount/investment)*100;
            printf("After two years he gets a loss of %d.",losspercentage);
         }
    return 0;
}