#include<stdio.h>
int main()
{
    int sum=0,rem,no,count,length,lenth,num,add=0,cout;
    printf("Enter the number:");
    scanf("%d",&num);
    no=num;
     printf("The Numbers are:");
    while(no!=0)
    {
        rem=no%10;
        printf(" %d ",rem);
        sum=sum+rem;
        count++;
        no=no/10;
    }
    printf("\nSum Of Digits:%d",sum);
    if(count>1)
    {
        while(cout!=1)
        {
    while(sum!=0)
    {
        rem=sum%10;
        add=add+rem;
        cout++;
        sum=sum/10;
    }
     sum=add;
        }
    }
    
    printf("\nNumerology Number:%d",sum);
    if(num%2!=0)
    {
        length++;
        printf("Number of odd numbers:%d",length);
    }
    else
    {
        lenth++;
        printf("Number of even numbers:%d",lenth);
    }
    return 0;
}
