#include<stdio.h>
int main()
{
    int arr[10],n,i,count=0,rem,rev=0;
    printf("Enter the size of an array:");
    scanf("%d",&n);
    printf("Enter the array elements:");
    for(i=0;i<n;i++)
    scanf("%d",&arr[i]);
    for(i=0;i<n;i++)
    {
        while(arr[i]!=0)
        {
            rem=arr[i]%10;
            count++;
            arr[i]=arr[i]/10;
        }
    if(count==1&&arr[i]%2!=0)
    {
         rev=(rev*10)+(arr[i]);
    }
    count=0;
    }
     printf("%d",rev);
    return 0;
}

