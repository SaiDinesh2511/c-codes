#include<stdio.h>
int main()
{
    char a[20];
    int evenbonus,oddbonus,distance,i,count,rem,no,num;
    printf("Enter the distance travelled");
    scanf("%d",&distance);
    if(distance<0)
    printf("invalid input");
    num=distance;
    while(num!=0)
    {
        rem=rem%10;
        count++;
        num=num/10;
    }
    no=distance;
    for(i=0;i<count;i++)
    {
        a[i]=no%10;
        no=no/10;
    }
    for(i=0;i<count/2;i+2)
    {
        evenbonus=a[i]*a[i+2];
    }
    for(i=1;i<count/2;i+2)
    {
        oddbonus=a[i]*a[i+2];
    }
    if(evenbonus>oddbonus)
    printf("your bonus points are %d",evenbonus);
    else 
    printf("your bonus points are %d",oddbonus);
    if(oddbonus=evenbonus)
    printf("your bonus points are %d",2*evenbonus);
    return 0;
}