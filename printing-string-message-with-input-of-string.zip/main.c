#include<stdio.h>
int main()
{
    char name[50];
    printf("Enter the name:");
    gets(name);
    printf("welcome %s!Achieve with all your might.",name);
    return 0;
}