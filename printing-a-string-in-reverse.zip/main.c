#include<stdio.h>
#include<string.h>
int main()
{
    char str[50],str1[50];
    int i=0,j,length;
    printf("Enter the string:");
    gets(str);
    length=strlen(str);
        for(j=length-1;j>=0;j--)
        {
            str1[j]=str[i];
            i++;
        }
    printf("%s",str1);
    return 0;
}