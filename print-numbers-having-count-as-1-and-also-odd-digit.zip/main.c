#include<stdio.h>
int main()
{
    int arr[20],n,i;
    printf("Enter the size of an array:");
    scanf("%d",&n);
    if(n<=0)
    printf("\nInvalid input");
    else
    {
    printf("\nEnter the array elements:");
    for(i=0;i<n;i++)
    scanf("%d",&arr[i]);
    for(i=0;i<n;i++)
    if(arr[i]>0&&arr[i]<10&&arr[i]%2!=0)
    printf("\n%d",arr[i]);
    }
    return 0;
    
}