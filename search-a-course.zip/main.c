#include<stdio.h>
#include<string.h>
int main()
{
    int n,i,j,flag=0;
     char a[15][15],search[20]; 
    printf("Enter no of course:");
    scanf("%d",&n);
    printf("Enter course names:");
    for(i=0;i<n;i++)
    gets(a[i]);
    printf("Enter the course to be searched:");
 gets(search);
      for(i=0;i<n;i++)
    {
     if(strcmp(a[i],search)==0)
     {
      flag=1;
     break;
     }
    }
    if(flag==1)
    printf("%s course is available",search);
    return 0;
}