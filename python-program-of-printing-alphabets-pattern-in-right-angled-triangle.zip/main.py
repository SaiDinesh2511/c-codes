t=65
for i in range(0,3,1):
    for j in range(0,i+1,1):
        print(chr(t+j),end=' ')
    print()