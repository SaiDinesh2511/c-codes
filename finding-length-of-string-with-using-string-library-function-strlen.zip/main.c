#include<stdio.h>
#include<string.h>
int main()
{
    char str[20];
    gets(str);
    printf("\n length of str is:%d",strlen(str));
    return 0;
}