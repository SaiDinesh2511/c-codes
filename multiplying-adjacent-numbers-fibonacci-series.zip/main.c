#include<stdio.h>
int main()
{
    int a,b,terms,i,prev,pres,new;
    printf("Enter the first number:");
    scanf("%d",&a);
    printf("\nEnter the second number:");
    scanf("%d",&b);
    printf("\nEnter the number of terms:");
    scanf("%d",&terms);
    if(a>=b)
    printf("\ninvalid input");
    else if(a<=0)
    printf("\ninvalid input");
    else if(b<=0)
    printf("\ninvalid input");
    else if(terms<=0)
    printf("\ninvalid input");
    else
    {
    printf("\n%d,",a);
    printf("%d,",b);
    prev=a;
    pres=b;
    new=(a*b);
    for(i=1;i<=terms;i++)
    {
        printf("%d,",new);
        prev=pres;
        pres=new;
        new=prev*pres;
    }
    }
    return 0;
}
    
