#include<stdio.h>
int main()
{
    char a[10];
    printf("Enter the name:\n");
    scanf("%s",a);
    printf("Welcome %s",a);
    return 0;
}