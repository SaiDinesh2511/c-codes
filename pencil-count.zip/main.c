#include<stdio.h>
int main()
{
    int standard=1,sum=0,i;
    printf("Enter the standard:");
    scanf("%d",&standard);
    for(i=1;i<=standard;i++)
    sum=(i)*(i)+(sum);
    if(standard<1||standard>12)
    printf("Invalid Standard");
    else
    printf("Nila gets %d pencils",sum);
    return 0;
}