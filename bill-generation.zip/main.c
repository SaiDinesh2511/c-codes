#include<stdio.h>
int main()
{
    int a,b,c,Tot;
    printf("Enter the no of pizzas bought:");
    scanf("%d",&a);
    printf("Enter the no of puffs bought:");
    scanf("%d",&b);
    printf("Enter the no of cool drinks bought:");
    scanf("%d",&c);
    printf("Bill Details\n");
    printf("No of pizzas:%d\n",a);
    printf("No of puffs:%d\n",b);
    printf("No of cooldrinks:%d\n",c);
    printf("Total price=%d\n",(a*100)+(b*20)+(c*10));
    printf("ENJOY THE SHOW!!!");
    return 0;
}