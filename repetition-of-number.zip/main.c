#include<stdio.h>
int main()
{
    char b[20];
    int count=0,sum=0,flag=1,a,i,num,key,rem;
    printf("Enter the number:");
    scanf("%d",&num);
    printf("Enter the key digit:");
    scanf("%d",&key);
    a=num;
    while(a!=0)
    {
        rem=a%10;
        count=count+1;
        a=a/10;
    }
    for(i=0;i<count;i++)
    {
        if(key==b[i])
        flag=sum+flag;
    }
    if(flag==0)
    printf("%d appears %d times in %d",key,flag,num);
    else
    printf("%d appears %d times in %d",key,flag,num);
    return 0;
}