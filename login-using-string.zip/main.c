#include<stdio.h>
#include<string.h>
int main()
{
    char a[20],b[20],c[20],d[20];
    int compare,comparing;
    printf("Enter the user name:");
    gets(a);
     printf("Enter the passsword:");
     gets(b);
     compare = strcmp(a,"john");
     comparing=strcmp(b,"123abc");
    if(compare==0&&comparing==0)
    printf("Valid user");
    else
    printf("INvalid user");
return 0;
    }

