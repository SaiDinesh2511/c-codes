#include<stdio.h>
int main()
{
    float Gradepoint;
    printf("Enter the grade point:");
    scanf("%f",&Gradepoint);
    if(Gradepoint==5)
    printf("Grade:O");
    if(Gradepoint>=4.5&&Gradepoint<5.0)
    printf("Grade:A");
    if(Gradepoint>=4.0&&Gradepoint<4.5)
    printf("Grade:B");
    if(Gradepoint>=3.0&&Gradepoint<4.0)
    printf("Grade:C");
    if(Gradepoint>=2.0&&Gradepoint<3.0)
    printf("Grade:D");
    if(Gradepoint>=1.0&&Gradepoint<2.0)
    printf("Grade:E");
    if(Gradepoint>=0.0&&Gradepoint<1.0)
    printf("Grade:F");
    return 0;
}