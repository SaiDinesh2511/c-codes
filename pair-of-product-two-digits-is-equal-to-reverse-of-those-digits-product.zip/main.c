#include<stdio.h>
int main()
{
    int a,b,rev=0,back=0,num,no,rem;
    scanf("%d",&a);
    scanf("%d",&b);
    num=a;
    while(num!=0)
    {
        rem=num%10;
        rev=(rev*10)+rem;
        num=num/10;
    }
    no=b;
    while(no!=0)
    {
        rem=no%10;
        back=(back*10)+rem;
        no=no/10;
    }
    if(a*b==rev*back)
    printf("Yes");
    else
    printf("Not");
    return 0;
}