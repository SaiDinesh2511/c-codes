#include<stdio.h>
int main()
{
        int arr[20],n,i,sum=0,j;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        scanf("%d",&arr[i]);
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                sum=sum+(arr[j]*arr[j]);
            }
            sum=(sum-(arr[i]*arr[i]));
            printf("%d\n",sum);
            sum=0;
        }
            return 0;
                }
        